<meta charset="utf-8">
<?php
$db=mysqli_connect('localhost','simbamar','wZ6q8ac7K3',
    'simbamar_hana');
?>

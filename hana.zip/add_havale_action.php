<?php
require_once 'connect.php';
require_once 'library/jdf.php';
require_once('library/tcpdf_min/tcpdf.php');

$query="INSERT INTO `hana`.`havale` (`id`, `date`) VALUES (NULL, '".jdate("y / m / d ")."');";
mysqli_query($db, "SET NAMES utf8");
if(mysqli_query($db,$query) === TRUE){

}
$test=0;
$date="";
$qury="SELECT * FROM havale   ORDER BY id DESC";
mysqli_query($db, "SET NAMES utf8");
$result=$db->query($qury);
if($result->num_rows >0) {
    while ($row = $result->fetch_array()) {
        if ($test==0){
            $id=$row['id'];
            $date=$row['date'];
            $test=1;
        }
    }
}
if (isset($_POST['name1'])){
    $query="INSERT INTO `under-havale` (`id`, `name`, `count`, `des`, `date`, `havale_id`) 
    VALUES (NULL, '".$_POST['name1']."', '".$_POST['count1']."', '".$_POST['des1']."', '".jdate("y / m / d ")."', '".$id."');";
    mysqli_query($db, "SET NAMES utf8");
    if(mysqli_query($db,$query) === TRUE){

    }
}

if (isset($_POST['name2']) && $_POST['name2'] !=""){
    $query="INSERT INTO `under-havale` (`id`, `name`, `count`, `des`, `date`, `havale_id`) 
    VALUES (NULL, '".$_POST['name2']."', '".$_POST['count2']."', '".$_POST['des2']."', '".jdate("y / m / d ")."', '".$id."');";
    mysqli_query($db, "SET NAMES utf8");
    if(mysqli_query($db,$query) === TRUE){

    }
}

if (isset($_POST['name3'])  && $_POST['name3'] !="" ){
    $query="INSERT INTO `under-havale` (`id`, `name`, `count`, `des`, `date`, `havale_id`) 
    VALUES (NULL, '".$_POST['name3']."', '".$_POST['count3']."', '".$_POST['des3']."', '".jdate("y / m / d ")."', '".$id."');";
    mysqli_query($db, "SET NAMES utf8");
    if(mysqli_query($db,$query) === TRUE){

    }
}







ob_start();

$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set font


// add a page
$pdf->AddPage();
$pdf->SetFont('xtraffic', '', 12);
$htmlpersian = "

<p style='text-align: left !important'>هانا الکترونیک </p>

";
$pdf->WriteHTML($htmlpersian, true, 0, true, 0);


$pdf->SetFont('xtitre', '', 12);
// Persian contentl
$htmlpersian = '
<body dir="rtl" style="text-align: center">
<br>
<table>
<tr>
<td>شماره : '."00".$id.'</td>
<td><h1>برگ خروج کالا</h1></td>
<td>تاریخ : '.$date.'</td>
</tr>
</table>
<br>
<br>
<table border="1px" cellpadding="5px">
<tr>
<td><b>ملاحضات </b>  </td>
<td><b>تعداد</b></td>
<td><b>شرح کالا</b>  </td>
</tr>';
$qury="SELECT * FROM  `under-havale` where havale_id =".$id;
mysqli_query($db, "SET NAMES utf8");
$result=$db->query($qury);
if($result->num_rows >0) {
    while ($row = $result->fetch_array()) {
        $htmlpersian .= '
        <tr>    
        <td>'.$row['des'].'</td>
        <td>'.$row['count'].'</td>
        <td>'.$row['name'].'</td>
        </tr>
        ';
    }
}
$htmlpersian .="</table>
<br>
<br>
<table>
<tr>
<td>امضای تحویل گرینده : </td>
<td> امضای صادر کننده  :  </td>
</tr>
</table>
";
$pdf->WriteHTML($htmlpersian, true, 0, true, 0);


$pdf->SetFont('xkoodak', '', 12);

// set LTR direction for english translation
$pdf->setRTL(false);


//Close and output PDF document
$pdf->Output();
?>


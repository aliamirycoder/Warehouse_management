<br>
<div class="container">
    <h3 style="text-align: right !important">سیستم انبار داری هانا الکترونیک </h3>
</div>
<ul class="navbar-panel">
    <div class="container">
        <a href="panel.php"><li>صفحه اصلی </li></a>
        <a href="havale.php"> <li> لیست حواله ها </li></a>
        <a href="mojody.php"><li> صورت وضعیت انبار </li></a>
        <a href="history.php"><li> تاریخچه </li></a>
    </div>
</ul>